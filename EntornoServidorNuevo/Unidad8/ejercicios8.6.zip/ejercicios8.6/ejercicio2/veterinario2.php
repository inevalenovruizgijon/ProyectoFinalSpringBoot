<?php
    // --- BLOQUE DE LECTURA DE FICHERO (CORREGIDO) ---
    $nombreFichero = "../archivos/animales.txt";
    $fechasDisponibles = [];
    $lineasFichero = [];

    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    // Usamos 'r' (read) porque solo vamos a leer.
    $fichero = fopen($nombreFichero, "r");
    if ($fichero) {
        while (!feof($fichero)) {
            // Leemos la fila y usamos trim() para quitar saltos de línea y espacios. ¡ESTO ES CLAVE!
            $fila = trim(fgets($fichero));

            // Si la línea no está vacía después de limpiarla, la procesamos.
            if (!empty($fila)) {
                $lineasFichero[] = $fila; // Guardamos la línea LIMPIA.
                if (str_contains($fila, "#")) {
                    $fechasDisponibles[] = $fila; // Guardamos la fecha LIMPIA.
                }
            }
        }
        // La forma correcta de cerrar el fichero.
        fclose($fichero);
    }
    // Para que no salgan fechas repetidas en el select.
    $fechasDisponibles = array_unique($fechasDisponibles);


    // --- BLOQUE DE PROCESAMIENTO DEL FORMULARIO (CORREGIDO) ---
    if (isset($_POST['enviar'])) {
        // Limpiamos la sesión para la nueva búsqueda.
        $_SESSION['mascotas_mostradas'] = [];

        if (!empty($_POST['fecha'])) {
            $fechaSeleccionada = $_POST['fecha']; // Ya viene limpia desde el 'option'.
            
            $fechaEncontrada = false;
            // Recorremos el array que ya hemos leído.
            foreach ($lineasFichero as $linea) {
                // Si la línea es una fecha...
                if (str_contains($linea, '#')) {
                    // Comprobamos si es la fecha que hemos seleccionado.
                    if ($linea == $fechaSeleccionada) {
                        $fechaEncontrada = true; // ¡Correcto! Activamos la bandera.
                    } else {
                        $fechaEncontrada = false; // Es otra fecha, desactivamos la bandera.
                    }
                    continue; // Saltamos la línea de fecha, no es una mascota.
                }

                // Si la bandera está activa, esta línea ES una mascota de la fecha correcta.
                if ($fechaEncontrada) {
                    $datos = explode('-', $linea);
                    if (count($datos) === 3) {
                        // Guardamos la mascota en la sesión.
                        $_SESSION['mascotas_mostradas'][] = [
                            'nombre' => $datos[0],
                            'animal' => $datos[1],
                            'edad'   => $datos[2],
                        ];
                    }
                }
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body { font-family: sans-serif; max-width: 700px; margin: auto; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <form action="" method="post">
        <!-- El name del select es 'fecha', como lo tenías. -->
        <select name="fecha">
            <option value="">-- Elige una fecha --</option>
            <?php
            // Llenamos el desplegable con las fechas.
            foreach ($fechasDisponibles as $f) {
                // Usamos la fecha limpia para el 'value' y para mostrarla.
                echo "<option value=\"$f\">$f</option>";
            }
            ?>
        </select>
        <input type="submit" value="enviar" name="enviar">
    </form>

    <!-- --- PARTE AÑADIDA PARA MOSTRAR LA TABLA --- -->
    <?php if (isset($_SESSION['mascotas_mostradas']) && !empty($_SESSION['mascotas_mostradas'])): ?>
        <h3>Mascotas encontradas:</h3>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Animal</th>
                    <th>Edad</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($_SESSION['mascotas_mostradas'] as $mascota): ?>
                    <tr>
                        <td><?php echo ($mascota['nombre']); ?></td>
                        <td><?php echo ($mascota['animal']); ?></td>
                        <td><?php echo htmlspecialchars($mascota['edad']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php elseif (isset($_POST['enviar'])): ?>
        <p>No se encontraron mascotas para la fecha seleccionada.</p>
    <?php endif; ?>

</body>
</html>