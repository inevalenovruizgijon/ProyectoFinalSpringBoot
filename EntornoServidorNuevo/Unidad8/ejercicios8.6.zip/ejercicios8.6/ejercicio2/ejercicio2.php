<!-- Diseñar una página que muestre un cuadro ‘select’ con todas las fechas disponibles en el fichero del ejercicio
anterior, de manera que al seleccionar y enviar una fecha, se cargue en un array de sesión las mascotas
almacenadas en la fecha seleccionada y las muestre en una tabla.
La opción de elegir una fecha siempre estará disponible para poder mostrar las mascotas de la fecha que interese,
es decir que se puede ir cambiando de fecha y se actualizan los datos de la tabla.
Nota: al leer una línea de un fichero se añaden espacios al principio o al final, así que para hacer comparaciones
debes asegurarte de quitar esos espacios. -->
<?php
    $nombreFichero="../archivos/animales.txt";
    $fechasDisponibles=[];
    $lineasFichero=[];
   if (session_status() == PHP_SESSION_NONE) session_start();  
   $fichero=fopen($nombreFichero,"a+");
    while(!feof($fichero)){
        $fila=fgets($fichero);
        $lineasFichero[]=$fila;
        if(str_contains($fila,"#")){
            $fechasDisponibles[]=$fila;
        }

    }
    $fichero=fclose($nombreFichero);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        <select value="fecha" name="fecha">
            <?php
                foreach ($fechasDisponibles as $f) {
                    echo "<option>$f</option>";
                }               
            ?>
        </select>
        <input type="submit" value="enviar" name="enviar">
        <?php
          if(isset($_POST['enviar'])){
            $_SESSION['mascotas']=[];
         $fecha=$_POST['fecha'];
         $fichero=fopen($nombreFichero,"a+");
         $fechaEncontrada=false;
         foreach ($lineasFichero as $linea) {
            if($linea==$fecha){
                $fechaEncontrada=true;
            }
            if($fechaEncontrada && str_contains($linea,"#")){
                $fechaEncontrada=false;
            }
         }                 
         };  
        ?>
    </form>
</body>
</html>